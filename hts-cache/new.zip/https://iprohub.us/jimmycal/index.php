<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>ROULETTE PRO</title>
  
   <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<link rel="stylesheet" href="css/screen.css">
<!-- <script src="js/jquery.js"></script> -->
<script src="js/jquery.validate.js"></script>


  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
<script>
	jQuery().ready(function() {
		// validate the comment form when it is submitted
		jQuery("#commentForm").validate();

	});
	</script>
<style>
	#commentForm {
		width: 100%;
	}
	#commentForm label {
		width: 250px;
	}
	#commentForm label.error, #commentForm input.submit {
		margin-left: 253px;
	} 
	 .form-module { 
  width: 1000px; 
}
</style>        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script type='text/javascript'>
        $(document).ready(function(){
            $('#commentForm input').keydown(function(e){
             if(e.keyCode==13){       

                if($(':input:eq(' + ($(':input').index(this) + 1) + ')').attr('type')=='submit'){// check for submit button and submit form on enter press
                 return true;
                }

                $(':input:eq(' + ($(':input').index(this) + 1) + ')').focus();

               return false;
             }

            });
        });
        </script>
        <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-115081646-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-115081646-1');
</script>

</head>

<body>
 <br><br>
<div class="module form-module" >
 
  <div class="form"> 
    <form> 
    </form>
  </div>
  <div class="form" >
  
 
 
 
<script src="js/standard.js" type="text/javascript"></script>
    <form  id="commentForm" name="formc" method="post" action="index.php">
    
     <table border=0 cellspacing=1 cellpadding="2"  width="100%">
		
		<tr>    
			<td align="center" width="100%"><a href="https://iprologic.com/" target="_blank"><img src="iprologo-350x287.png" width="350" align="center" ></a></td> 
		</tr>  
	</table>   
  
 
  <TABLE border=0 cellSpacing=1 cellPadding=2  width=930>
 
  <tr>  
  <td class="rtd">Date</td> 
  <td  class="ctaa clearformd" align=center><span style =""><a  href="index.php?session=clear" style="color: #ffffff;text-decoration: none;">clear </a></span> </td> 
  <td class="ctaa" > <button onclick="document.getElementById('formc').submit();" style="margin-top: -1px;">Save</button></td> 
  <td class="rtd" >TOTAL INVESTED </td> 
  
  <td width=300>  </td> 
  
  <td class="rtd" width=150>TOTAL RETURNS </td> 
  <td class="rtd" width=170>STARTING BANKROLL</td> 
  <td class="rtd" width=170>CURRENT BANKROLL</td> 
    </tr>  
      <tr>  
  <td class="ctaa"><input type="text" class="inputs" id="Date" name="Date"  placeholder="15-11-2022" onChange="calculateDiscount(); return false;"></td>
  <td >  </td> 
  <td >  </td> 
  <td class="ctaa"><input type="text" class="inputs" id="T_INVESTED" name="T_INVESTED"  placeholder="0"  onChange="calculateDiscount(); return false;"></td> 
  
  <td  >  </td> 
  
  <td class="ctaa"><input type="text" class="inputs" id="T_RETURNS" name="T_RETURNS"  placeholder="0"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa">
  <input type="text" class="inputs" id="J7_H" name="J7_H" value=0 placeholder="20000"  ></td> 
  <td class="ctaa">
  <input type="text" class="inputs" id="J7" name="J7" value=0 placeholder="20000"  ></td> 
  </tr> 
      <tr>  
  <td  colspan=3  >  </td> 
  <td class="ctaa"><input type="text" class="inputs" id="Ex5" name="Ex5"  placeholder="2"  onChange="calculateDiscount(); return false;"></td> 
  
  <td  class="ctaa" colspan=2>ADJUST  TO DESIRED $ TARGET PROFIT PER INVESTMENT</td>  
  <td></td> 
  </tr> 
   </TABLE> 
    <TABLE border=0 cellSpacing=1 cellPadding=2   width=930>
  <tr>  
  <td class="rtd">CURRENT SPIN #</td> 
  <td class="rtd">MATRIX SEQ #S</td> 
  <td class="rtd">ODDS</td> 
  <td class="rtd">INVEST</td> 
  <td class="rtd">WIN</td> 
  <td class="rtd" width=5> </td> 
  <td class="rtd">PAY</td> 
  <td class="rtd" width=200>RETURN TTL $ AMOUNT</td> 
  </tr>
 

    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B1" name="B1"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C1" name="C1"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D1" name="D1"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E1" name="E1"   onchange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F1" name="F1"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H1" name="H1"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I1" name="I1"   onChange="calculateDiscount(); return false;"></td> 
  </tr>   
 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B2" name="B2"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C2" name="C2"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D2" name="D2"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E2" name="E2"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F2" name="F2"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H2" name="H2"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I2" name="I2"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B3" name="B3"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C3" name="C3"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D3" name="D3"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E3" name="E3"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F3" name="F3"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H3" name="H3"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I3" name="I3"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B4" name="B4"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C4" name="C4"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D4" name="D4"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E4" name="E4"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F4" name="F4"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H4" name="H4"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I4" name="I4"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B5" name="B5"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C5" name="C5"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D5" name="D5"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E5" name="E5"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F5" name="F5"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H5" name="H5"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I5" name="I5"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B6" name="B6"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C6" name="C6"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D6" name="D6"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E6" name="E6"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F6" name="F6"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H6" name="H6"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I6" name="I6"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B7" name="B7"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C7" name="C7"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D7" name="D7"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E7" name="E7"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F7" name="F7"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H7" name="H7"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I7" name="I7"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B8" name="B8"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C8" name="C8"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D8" name="D8"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E8" name="E8"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F8" name="F8"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H8" name="H8"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I8" name="I8"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B9" name="B9"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C9" name="C9"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D9" name="D9"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E9" name="E9"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F9" name="F9"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H9" name="H9"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I9" name="I9"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B10" name="B10"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C10" name="C10"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D10" name="D10"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E10" name="E10"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F10" name="F10"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H10" name="H10"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I10" name="I10"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B11" name="B11"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C11" name="C11"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D11" name="D11"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E11" name="E11"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F11" name="F11"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H11" name="H11"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I11" name="I11"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B12" name="B12"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C12" name="C12"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D12" name="D12"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E12" name="E12"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F12" name="F12"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H12" name="H12"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I12" name="I12"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B13" name="B13"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C13" name="C13"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D13" name="D13"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E13" name="E13"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F13" name="F13"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H13" name="H13"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I13" name="I13"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B14" name="B14"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C14" name="C14"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D14" name="D14"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E14" name="E14"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F14" name="F14"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H14" name="H14"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I14" name="I14"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B15" name="B15"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C15" name="C15"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D15" name="D15"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E15" name="E15"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F15" name="F15"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H15" name="H15"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I15" name="I15"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B16" name="B16"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C16" name="C16"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D16" name="D16"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E16" name="E16"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F16" name="F16"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H16" name="H16"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I16" name="I16"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B17" name="B17"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C17" name="C17"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D17" name="D17"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E17" name="E17"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F17" name="F17"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H17" name="H17"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I17" name="I17"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B18" name="B18"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C18" name="C18"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D18" name="D18"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E18" name="E18"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F18" name="F18"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H18" name="H18"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I18" name="I18"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B19" name="B19"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C19" name="C19"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D19" name="D19"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E19" name="E19"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F19" name="F19"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H19" name="H19"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I19" name="I19"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B20" name="B20"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C20" name="C20"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D20" name="D20"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E20" name="E20"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F20" name="F20"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H20" name="H20"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I20" name="I20"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B21" name="B21"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C21" name="C21"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D21" name="D21"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E21" name="E21"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F21" name="F21"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H21" name="H21"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I21" name="I21"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B22" name="B22"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C22" name="C22"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D22" name="D22"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E22" name="E22"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F22" name="F22"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H22" name="H22"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I22" name="I22"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B23" name="B23"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C23" name="C23"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D23" name="D23"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E23" name="E23"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F23" name="F23"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H23" name="H23"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I23" name="I23"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B24" name="B24"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C24" name="C24"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D24" name="D24"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E24" name="E24"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F24" name="F24"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H24" name="H24"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I24" name="I24"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B25" name="B25"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C25" name="C25"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D25" name="D25"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E25" name="E25"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F25" name="F25"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H25" name="H25"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I25" name="I25"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B26" name="B26"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C26" name="C26"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D26" name="D26"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E26" name="E26"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F26" name="F26"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H26" name="H26"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I26" name="I26"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B27" name="B27"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C27" name="C27"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D27" name="D27"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E27" name="E27"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F27" name="F27"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H27" name="H27"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I27" name="I27"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B28" name="B28"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C28" name="C28"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D28" name="D28"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E28" name="E28"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F28" name="F28"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H28" name="H28"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I28" name="I28"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B29" name="B29"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C29" name="C29"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D29" name="D29"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E29" name="E29"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F29" name="F29"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H29" name="H29"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I29" name="I29"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B30" name="B30"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C30" name="C30"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D30" name="D30"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E30" name="E30"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F30" name="F30"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H30" name="H30"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I30" name="I30"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B31" name="B31"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C31" name="C31"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D31" name="D31"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E31" name="E31"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F31" name="F31"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H31" name="H31"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I31" name="I31"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B32" name="B32"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C32" name="C32"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D32" name="D32"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E32" name="E32"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F32" name="F32"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H32" name="H32"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I32" name="I32"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B33" name="B33"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C33" name="C33"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D33" name="D33"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E33" name="E33"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F33" name="F33"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H33" name="H33"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I33" name="I33"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B34" name="B34"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C34" name="C34"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D34" name="D34"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E34" name="E34"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F34" name="F34"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H34" name="H34"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I34" name="I34"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B35" name="B35"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C35" name="C35"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D35" name="D35"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E35" name="E35"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F35" name="F35"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H35" name="H35"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I35" name="I35"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B36" name="B36"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C36" name="C36"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D36" name="D36"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E36" name="E36"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F36" name="F36"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H36" name="H36"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I36" name="I36"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B37" name="B37"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C37" name="C37"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D37" name="D37"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E37" name="E37"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F37" name="F37"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H37" name="H37"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I37" name="I37"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B38" name="B38"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C38" name="C38"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D38" name="D38"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E38" name="E38"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F38" name="F38"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H38" name="H38"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I38" name="I38"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B39" name="B39"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C39" name="C39"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D39" name="D39"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E39" name="E39"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F39" name="F39"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H39" name="H39"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I39" name="I39"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B40" name="B40"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C40" name="C40"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D40" name="D40"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E40" name="E40"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F40" name="F40"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H40" name="H40"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I40" name="I40"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B41" name="B41"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C41" name="C41"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D41" name="D41"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E41" name="E41"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F41" name="F41"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H41" name="H41"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I41" name="I41"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B42" name="B42"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C42" name="C42"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D42" name="D42"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E42" name="E42"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F42" name="F42"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H42" name="H42"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I42" name="I42"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B43" name="B43"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C43" name="C43"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D43" name="D43"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E43" name="E43"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F43" name="F43"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H43" name="H43"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I43" name="I43"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B44" name="B44"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C44" name="C44"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D44" name="D44"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E44" name="E44"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F44" name="F44"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H44" name="H44"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I44" name="I44"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B45" name="B45"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C45" name="C45"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D45" name="D45"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E45" name="E45"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F45" name="F45"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H45" name="H45"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I45" name="I45"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B46" name="B46"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C46" name="C46"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D46" name="D46"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E46" name="E46"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F46" name="F46"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H46" name="H46"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I46" name="I46"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B47" name="B47"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C47" name="C47"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D47" name="D47"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E47" name="E47"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F47" name="F47"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H47" name="H47"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I47" name="I47"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B48" name="B48"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C48" name="C48"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D48" name="D48"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E48" name="E48"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F48" name="F48"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H48" name="H48"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I48" name="I48"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B49" name="B49"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C49" name="C49"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D49" name="D49"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E49" name="E49"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F49" name="F49"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H49" name="H49"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I49" name="I49"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B50" name="B50"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C50" name="C50"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D50" name="D50"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E50" name="E50"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F50" name="F50"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H50" name="H50"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I50" name="I50"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B51" name="B51"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C51" name="C51"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D51" name="D51"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E51" name="E51"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F51" name="F51"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H51" name="H51"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I51" name="I51"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B52" name="B52"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C52" name="C52"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D52" name="D52"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E52" name="E52"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F52" name="F52"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H52" name="H52"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I52" name="I52"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B53" name="B53"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C53" name="C53"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D53" name="D53"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E53" name="E53"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F53" name="F53"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H53" name="H53"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I53" name="I53"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B54" name="B54"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C54" name="C54"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D54" name="D54"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E54" name="E54"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F54" name="F54"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H54" name="H54"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I54" name="I54"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B55" name="B55"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C55" name="C55"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D55" name="D55"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E55" name="E55"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F55" name="F55"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H55" name="H55"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I55" name="I55"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B56" name="B56"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C56" name="C56"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D56" name="D56"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E56" name="E56"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F56" name="F56"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H56" name="H56"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I56" name="I56"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B57" name="B57"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C57" name="C57"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D57" name="D57"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E57" name="E57"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F57" name="F57"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H57" name="H57"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I57" name="I57"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B58" name="B58"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C58" name="C58"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D58" name="D58"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E58" name="E58"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F58" name="F58"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H58" name="H58"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I58" name="I58"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B59" name="B59"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C59" name="C59"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D59" name="D59"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E59" name="E59"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F59" name="F59"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H59" name="H59"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I59" name="I59"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B60" name="B60"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C60" name="C60"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D60" name="D60"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E60" name="E60"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F60" name="F60"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H60" name="H60"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I60" name="I60"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B61" name="B61"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C61" name="C61"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D61" name="D61"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E61" name="E61"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F61" name="F61"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H61" name="H61"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I61" name="I61"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B62" name="B62"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C62" name="C62"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D62" name="D62"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E62" name="E62"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F62" name="F62"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H62" name="H62"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I62" name="I62"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B63" name="B63"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C63" name="C63"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D63" name="D63"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E63" name="E63"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F63" name="F63"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H63" name="H63"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I63" name="I63"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B64" name="B64"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C64" name="C64"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D64" name="D64"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E64" name="E64"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F64" name="F64"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H64" name="H64"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I64" name="I64"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B65" name="B65"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C65" name="C65"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D65" name="D65"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E65" name="E65"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F65" name="F65"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H65" name="H65"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I65" name="I65"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B66" name="B66"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C66" name="C66"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D66" name="D66"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E66" name="E66"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F66" name="F66"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H66" name="H66"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I66" name="I66"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B67" name="B67"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C67" name="C67"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D67" name="D67"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E67" name="E67"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F67" name="F67"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H67" name="H67"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I67" name="I67"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B68" name="B68"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C68" name="C68"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D68" name="D68"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E68" name="E68"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F68" name="F68"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H68" name="H68"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I68" name="I68"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B69" name="B69"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C69" name="C69"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D69" name="D69"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E69" name="E69"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F69" name="F69"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H69" name="H69"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I69" name="I69"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B70" name="B70"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C70" name="C70"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D70" name="D70"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E70" name="E70"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F70" name="F70"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H70" name="H70"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I70" name="I70"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B71" name="B71"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C71" name="C71"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D71" name="D71"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E71" name="E71"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F71" name="F71"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H71" name="H71"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I71" name="I71"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B72" name="B72"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C72" name="C72"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D72" name="D72"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E72" name="E72"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F72" name="F72"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H72" name="H72"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I72" name="I72"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B73" name="B73"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C73" name="C73"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D73" name="D73"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E73" name="E73"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F73" name="F73"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H73" name="H73"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I73" name="I73"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B74" name="B74"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C74" name="C74"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D74" name="D74"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E74" name="E74"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F74" name="F74"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H74" name="H74"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I74" name="I74"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B75" name="B75"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C75" name="C75"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D75" name="D75"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E75" name="E75"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F75" name="F75"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H75" name="H75"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I75" name="I75"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B76" name="B76"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C76" name="C76"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D76" name="D76"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E76" name="E76"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F76" name="F76"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H76" name="H76"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I76" name="I76"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B77" name="B77"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C77" name="C77"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D77" name="D77"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E77" name="E77"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F77" name="F77"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H77" name="H77"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I77" name="I77"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B78" name="B78"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C78" name="C78"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D78" name="D78"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E78" name="E78"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F78" name="F78"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H78" name="H78"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I78" name="I78"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B79" name="B79"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C79" name="C79"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D79" name="D79"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E79" name="E79"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F79" name="F79"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H79" name="H79"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I79" name="I79"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B80" name="B80"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C80" name="C80"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D80" name="D80"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E80" name="E80"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F80" name="F80"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H80" name="H80"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I80" name="I80"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B81" name="B81"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C81" name="C81"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D81" name="D81"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E81" name="E81"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F81" name="F81"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H81" name="H81"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I81" name="I81"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B82" name="B82"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C82" name="C82"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D82" name="D82"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E82" name="E82"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F82" name="F82"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H82" name="H82"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I82" name="I82"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B83" name="B83"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C83" name="C83"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D83" name="D83"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E83" name="E83"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F83" name="F83"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H83" name="H83"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I83" name="I83"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B84" name="B84"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C84" name="C84"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D84" name="D84"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E84" name="E84"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F84" name="F84"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H84" name="H84"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I84" name="I84"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B85" name="B85"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C85" name="C85"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D85" name="D85"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E85" name="E85"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F85" name="F85"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H85" name="H85"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I85" name="I85"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B86" name="B86"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C86" name="C86"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D86" name="D86"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E86" name="E86"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F86" name="F86"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H86" name="H86"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I86" name="I86"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B87" name="B87"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C87" name="C87"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D87" name="D87"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E87" name="E87"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F87" name="F87"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H87" name="H87"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I87" name="I87"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B88" name="B88"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C88" name="C88"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D88" name="D88"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E88" name="E88"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F88" name="F88"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H88" name="H88"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I88" name="I88"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B89" name="B89"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C89" name="C89"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D89" name="D89"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E89" name="E89"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F89" name="F89"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H89" name="H89"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I89" name="I89"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B90" name="B90"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C90" name="C90"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D90" name="D90"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E90" name="E90"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F90" name="F90"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H90" name="H90"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I90" name="I90"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B91" name="B91"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C91" name="C91"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D91" name="D91"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E91" name="E91"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F91" name="F91"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H91" name="H91"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I91" name="I91"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B92" name="B92"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C92" name="C92"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D92" name="D92"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E92" name="E92"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F92" name="F92"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H92" name="H92"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I92" name="I92"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B93" name="B93"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C93" name="C93"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D93" name="D93"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E93" name="E93"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F93" name="F93"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H93" name="H93"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I93" name="I93"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B94" name="B94"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C94" name="C94"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D94" name="D94"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E94" name="E94"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F94" name="F94"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H94" name="H94"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I94" name="I94"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B95" name="B95"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C95" name="C95"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D95" name="D95"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E95" name="E95"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F95" name="F95"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H95" name="H95"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I95" name="I95"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B96" name="B96"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C96" name="C96"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D96" name="D96"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E96" name="E96"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F96" name="F96"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H96" name="H96"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I96" name="I96"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B97" name="B97"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C97" name="C97"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D97" name="D97"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E97" name="E97"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F97" name="F97"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H97" name="H97"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I97" name="I97"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B98" name="B98"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C98" name="C98"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D98" name="D98"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E98" name="E98"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F98" name="F98"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H98" name="H98"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I98" name="I98"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B99" name="B99"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C99" name="C99"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D99" name="D99"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E99" name="E99"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F99" name="F99"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H99" name="H99"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I99" name="I99"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  


 
    <tr>   
  <td class="ctaa"><input type="text" class="inputs" id="B100" name="B100"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="C100" name="C100"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="D100" name="D100"  onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="E100" name="E100"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ctaa"><input type="text" class="inputs" id="F100" name="F100"   onChange="calculateDiscount(); return false;"></td> 
  <td> </td> 
  <td class="ctaa"><input type="text" class="inputs" id="H100" name="H100"   onChange="calculateDiscount(); return false;"></td> 
  <td class="ytd"><input type="text" class="inputs" id="I100" name="I100"   onChange="calculateDiscount(); return false;"></td> 
  </tr>  
</TABLE><br>
      <TABLE border=0 cellSpacing=1 cellPadding=2  width=930> 
 <tr>  <td  align=right>  
  <TABLE border=0 cellSpacing=1 cellPadding=2  width=200 > 
 <tr> 
  <td class="clearformd"><span style =""><a  href="index.php?session=clear" style="color: #ffffff;text-decoration: none;">clear </a></span>   </TD ><td > <button onclick="document.getElementById('formc').submit();" style="margin-top: -1px;">Save</button>  </TD >   </tr> 
  </TABLE> </TD ></tr> 
  </TABLE>
    </form> 

      <br> <br>
  </div>
  </div>
  	 <script type="text/javascript">
	 	jQuery(document).ready(function(){
				  
		 	
		    jQuery("#B1").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B1").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C1").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B2").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B2").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C2").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B3").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B3").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C3").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B4").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B4").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C4").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B5").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B5").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C5").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B6").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B6").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C6").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B7").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B7").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C7").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B8").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B8").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C8").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B9").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B9").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C9").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B10").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B10").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C10").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B11").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B11").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C11").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B12").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B12").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C12").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B13").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B13").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C13").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B14").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B14").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C14").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B15").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B15").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C15").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B16").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B16").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C16").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B17").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B17").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C17").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B18").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B18").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C18").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B19").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B19").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C19").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B20").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B20").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C20").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B21").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B21").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C21").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B22").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B22").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C22").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B23").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B23").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C23").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B24").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B24").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C24").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B25").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B25").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C25").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B26").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B26").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C26").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B27").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B27").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C27").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B28").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B28").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C28").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B29").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B29").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C29").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B30").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B30").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C30").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B31").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B31").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C31").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B32").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B32").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C32").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B33").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B33").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C33").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B34").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B34").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C34").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B35").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B35").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C35").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B36").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B36").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C36").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B37").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B37").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C37").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B38").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B38").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C38").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B39").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B39").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C39").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B40").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B40").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C40").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B41").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B41").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C41").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B42").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B42").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C42").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B43").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B43").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C43").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B44").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B44").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C44").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B45").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B45").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C45").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B46").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B46").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C46").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B47").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B47").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C47").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B48").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B48").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C48").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B49").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B49").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C49").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B50").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B50").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C50").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B51").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B51").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C51").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B52").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B52").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C52").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B53").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B53").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C53").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B54").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B54").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C54").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B55").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B55").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C55").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B56").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B56").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C56").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B57").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B57").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C57").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B58").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B58").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C58").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B59").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B59").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C59").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B60").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B60").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C60").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B61").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B61").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C61").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B62").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B62").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C62").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B63").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B63").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C63").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B64").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B64").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C64").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B65").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B65").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C65").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B66").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B66").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C66").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B67").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B67").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C67").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B68").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B68").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C68").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B69").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B69").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C69").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B70").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B70").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C70").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B71").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B71").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C71").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B72").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B72").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C72").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B73").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B73").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C73").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B74").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B74").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C74").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B75").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B75").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C75").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B76").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B76").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C76").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B77").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B77").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C77").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B78").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B78").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C78").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B79").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B79").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C79").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B80").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B80").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C80").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B81").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B81").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C81").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B82").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B82").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C82").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B83").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B83").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C83").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B84").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B84").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C84").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B85").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B85").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C85").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B86").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B86").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C86").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B87").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B87").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C87").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B88").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B88").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C88").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B89").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B89").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C89").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B90").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B90").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C90").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B91").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B91").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C91").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B92").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B92").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C92").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B93").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B93").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C93").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B94").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B94").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C94").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B95").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B95").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C95").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B96").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B96").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C96").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B97").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B97").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C97").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B98").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B98").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C98").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B99").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B99").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C99").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
				  
		 	
		    jQuery("#B100").change(function(){
		       var metrix_val;
		        metrix_val = jQuery("#B100").val();
		        if(metrix_val > 0 && metrix_val <= 36)
			        {
			        	
		        //alert(metrix_val);
		        jQuery.post("cal_metrix.php", { id1: metrix_val }).done(function(data) {
		         jQuery("#C100").val(data);
		            //alert( data );
		        });
		        return false; //true(post form data)	
		        }
		        else
		        {
		        	alert('value should be between 1 to 36.')
			     
		        }	        
		    });
		 
		}); 
	</script>
 

  <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script  src="js/index.js"></script>
</body>
</html>
